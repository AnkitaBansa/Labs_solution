## **Develop an app with Gemini**

##

```
export REGION=
```


```
curl -LO raw.githubusercontent.com/quiccklabs/Labs_solutions/master/Develop%20an%20app%20with%20Gemini/quicklab.sh

sudo chmod +x quicklab.sh

./quicklab.sh
```
### ```Check the score for TASK 1.```



### ***```Perfrom Task 2 from lab instruction as shown in video.```*** 

### ```Check the score for TASK 2.```



### **Click here to download these files:**

- ***File 1:*** **[inventory.py](https://github.com/quiccklabs/Labs_solutions/blob/master/Develop%20an%20app%20with%20Gemini/inventory.py)**
- ***File 2:*** **[app.py](https://github.com/quiccklabs/Labs_solutions/blob/master/Develop%20an%20app%20with%20Gemini/app.py)**









### **```Note: It might take up to 5 minutes to update the score.```** 

### Congratulation!!!