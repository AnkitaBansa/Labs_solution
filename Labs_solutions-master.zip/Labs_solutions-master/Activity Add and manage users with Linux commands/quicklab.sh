




sudo useradd researcher9

sudo usermod -aG research_team researcher9

sudo chown researcher9:research_team /home/researcher2/projects/project_r.txt

sudo usermod -aG sales_team researcher9



