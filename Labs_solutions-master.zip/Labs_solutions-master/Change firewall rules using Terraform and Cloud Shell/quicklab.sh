

gcloud auth list

git clone https://github.com/terraform-google-modules/docs-examples.git

cd docs-examples/firewall_basic/

terraform init

terraform apply --auto-approve

terraform init

terraform apply --auto-approve
