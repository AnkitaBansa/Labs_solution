

echo hello
echo "hello"
echo "Quicklab"

expr 32 - 8
expr 3500 \* 12

clear

