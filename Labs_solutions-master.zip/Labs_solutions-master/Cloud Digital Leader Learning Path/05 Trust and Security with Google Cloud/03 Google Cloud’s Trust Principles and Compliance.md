# Google Cloud’s Trust Principles and Compliance

1. **Which is one of Google Cloud’s seven trust principles?**

   - **All customer data is encrypted by default.**

2. **Which report provides a way for Google Cloud to share data about how the policies and actions of governments and corporations affect privacy, security, and access to information?**

   - **Transparency reports**

3. **Which Google Cloud feature allows users to control their data's physical location?**

   - **Regions**

4. **Where can you find details about certifications and compliance standards met by Google Cloud?**

   - **Compliance resource center**

5. **Which term describes the concept that data is subject to the laws and regulations of the country where it resides?**

   - **Data sovereignty**
