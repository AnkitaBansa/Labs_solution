# Sustainability with Google Cloud

1. **Google's data centers were the first to achieve ISO 14001 certification. What is this standard’s purpose?**

   - **It’s a framework for an organization to enhance its environmental performance through improving resource efficiency and reducing waste.**

2. **Kaluza is an electric vehicle smart-charging solution. How does it use BigQuery and Looker Studio?**

   - **It uses BigQuery and Looker Studio to create dashboards that provide granular operational insights.**

3. **What sustainability goal does Google aim to achieve by the year 2030?**

   - **To be the first major company to operate completely carbon free.**

